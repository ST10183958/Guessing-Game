package com.example.numberguesser

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import com.google.android.material.textfield.TextInputEditText
import kotlin.random.Random

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var DisplayValue = findViewById<TextView>(R.id.DisplayValue)
        var InputValue = findViewById<TextInputEditText>(R.id.InputEdit)
        var ConfirmButton = findViewById<Button>(R.id.ConfirmButton)

        val GeneratedValue = List(1) { Random.nextInt(0, 100) }

        ConfirmButton.setOnClickListener {
            if (InputValue.text == GeneratedValue) {
                DisplayValue.text == "You answered Correctly"
            } else {
                DisplayValue.text == "You answered Incorrectly" + GeneratedValue.toString()
            }
        }
    }
}